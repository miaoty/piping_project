该目录为sample所需的库目录
可通过lib_copy.sh将共享库复制到该目录
分别为：libiruvc.so libirparse.so libirprocess.so libirtemp.so